from fastapi import APIRouter, HTTPException
from app.schemas.models import CropPredictionRequest, CropPredictionResponse
from app.services.crop_service import CropService

router = APIRouter()
crop_service = CropService()

@router.post("/predict-crop", response_model=CropPredictionResponse)
async def predict_crop(request: CropPredictionRequest):
    try:
        result = crop_service.predict(request)
        return CropPredictionResponse(**result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
