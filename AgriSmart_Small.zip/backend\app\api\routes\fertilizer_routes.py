from fastapi import APIRouter, HTTPException
from app.schemas.models import FertilizerPredictionRequest, FertilizerResponse
from app.services.fertilizer_service import FertilizerService

router = APIRouter()
fertilizer_service = FertilizerService()

@router.post("/predict-fertilizer", response_model=FertilizerResponse)
async def predict_fertilizer(request: FertilizerPredictionRequest):
    try:
        result = fertilizer_service.predict(request)
        return FertilizerResponse(**result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
